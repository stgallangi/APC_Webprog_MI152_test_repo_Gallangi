<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<html>
<head>
<style>
#para1 {
font-family: "Time New Roman", Times, serif;
font-size: 70px;
color: Black;
}
#para2 {
font-family: "Time New Roman", Times, serif;
font-size: 90px;
color: Black;
}
#para3 {
font-family: "Time New Roman", Times, serif;
font-size: 30px;
color: Black;
}

body {
    background-color: black;
}


</style>
	</head>
	<body>

<div class="about_view">
    <h1><?= Html::encode($this->title) ?></h1>

    <table width="100%"  border="0">
 <tr>
 <td bgcolor="#b5dcb3" height = "100">
  <p id="para1"> Stevenson Gallangi </p>
 </hr>

<tr>
  <td bgcolor="#eee" height="900" align ="center"/>
 
 <p id="para2"> Hobbies and Interest </p>
 </br>

  <img src = "me2.jpg" width="400" height="300" ></center>
 </br>
  </br>
   </br>
 <button type="button" onclick="document.getElementById('para3').style.display='block'">Click here if you want to learn more about me</button>
 </br>
 <p id="para3" style="display:none">
 I enjoy my free time by sleeping because it makes me calm and </br>
 it feels good to sleep as well as eating. I also like to read </br>
 novel books and teen fiction books and I have already read a lot </br>
 of books, book series, and even non-mainstream books.</br>
 </br>
  I also enjoy watching anime because I learn a lot of new things </br>
  just like in reading. In anime, I also learn some Japanese words </br>
  which was nice and also in anime you can experience some things </br>
  you did not experienced yet. You can even learn some things in</br>
  here that you can actually use in the real life.</br>
  
  </br>
  </br>
  <img src = "me.jpg" width="400" height="300" ></center>

  </br>
  </br>
 
  I can say that listening to music is a part of my life. </br>
  Songs from my favorite artists like, The Vamps, Maroon 5, </br>
  All Time Low, P!ATD, and a lot more. I will share something </br>
  on you. I like All Time Low and Maroon 5 because they try </br>
  creating new songs in a genre they did not use before and it  </br>
  always comes out as good as if they were doing it a long time </br>
  ago. I was relieved when I heard and saw a new about the reunion</br>
  of the band My Chemical Romance and I am excited for their next</br>
  recordings this year.
  
  </br>
  </br>
 So these are some of the things I enjoy a lot and also I like playing </br>
 games. I am a big fan of pokemon, I have played almost all the version  </br>
 of it even if I don’t even have a Gameboy or a DS thanks to smartphones. I enjoy photography</br>
 
 </br>
 </br>

 
  </p>
 </tr>
 <tr>
 <td colspan="2" bgcolor="#b5dcb3">
 <center>
 Copyright ©StevensonGallangi
 </center>
 </td>
 </tr>
</table>
</div>
</body>
<center>

</div>